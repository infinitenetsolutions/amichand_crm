<?php 
    $randSix = rand(111111,999999);
    $randFour = rand(1111,9999);
?>