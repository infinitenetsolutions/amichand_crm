    <script src="<?php echo base_url() ?>/assets/js/app.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url() ?>/assets/js/theme/default.min.js" type="text/javascript"></script>    
    <!-- <script src="https://ajax.cloudflare.com/cdn-cgi/scripts/7089c43e/cloudflare-static/rocket-loader.min.js" data-cf-settings="|49" defer=""></script> -->

</body>
</html>
